#!/bin/bash

cd "$(dirname "$(readlink -f "$0")")"

export AMD_VULKAN_ICD=RADV

./shoal
